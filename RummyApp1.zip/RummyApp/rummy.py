#!/usr/bin/env python3
"""
Rummy with Friends - one-file server.

Run:   python rummy.py          (or: python rummy.py 8080 to pick a port)
Then:  open the address it prints on every phone/laptop on the same Wi-Fi.

Needs only Python 3.8+ (no installs). Games are saved to rummy_data.json
next to this file, so a restart doesn't lose tables.
"""
import json, os, re, socket, sys, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rummy_data.json")
CODE_RE = re.compile(r"^[A-Z0-9]{5}$")
MAX_BODY = 1_000_000
KEEP_DAYS = 7

lock = threading.Lock()
games = {}


def load():
    global games
    try:
        with open(DATA_FILE, encoding="utf-8") as f:
            games = json.load(f)
    except (FileNotFoundError, ValueError):
        games = {}
    cutoff = (time.time() - KEEP_DAYS * 86400) * 1000
    games = {k: v for k, v in games.items() if isinstance(v, dict) and v.get("createdAt", 0) > cutoff}


def save():
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(games, f, separators=(",", ":"))
    os.replace(tmp, DATA_FILE)


def merge(a, b):
    """Nested objects merge; everything else (lists, numbers, null) replaces."""
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(a.get(k), dict):
            merge(a[k], v)
        else:
            a[k] = v


class Handler(BaseHTTPRequestHandler):
    def _send(self, status, body, ctype="application/json"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(status)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, status, obj):
        self._send(status, json.dumps(obj, separators=(",", ":")))

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            return self._send(200, PAGE, "text/html")
        if path == "/api/games":
            with lock:
                items = sorted(games.items(), key=lambda kv: kv[1].get("createdAt", 0), reverse=True)[:25]
                keys = ("createdAt", "updatedAt", "host", "status", "players", "cur")
                return self._json(200, [dict({f: v.get(f) for f in keys}, id=k) for k, v in items])
        m = re.match(r"^/api/game/([A-Z0-9]{5})$", path)
        if m:
            with lock:
                g = games.get(m.group(1))
                return self._json(200, {"exists": g is not None, "data": g})
        self._json(404, {"error": "not found"})

    def do_POST(self):
        m = re.match(r"^/api/game/([A-Z0-9]{5})$", self.path.split("?")[0])
        if not m:
            return self._json(404, {"error": "not found"})
        code = m.group(1)
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n <= 0 or n > MAX_BODY:
                raise ValueError("bad size")
            body = json.loads(self.rfile.read(n))
            op = body.get("op")
            data = body.get("data")
        except Exception:
            return self._json(400, {"error": "bad request"})
        with lock:
            if op == "set" and isinstance(data, dict):
                games[code] = data
            elif op == "update" and isinstance(data, dict):
                if code not in games:
                    return self._json(400, {"error": "no such table"})
                merge(games[code], data)
            elif op == "delete":
                games.pop(code, None)
            else:
                return self._json(400, {"error": "bad op"})
            if code in games:
                games[code]["updatedAt"] = int(time.time() * 1000)
            try:
                save()
            except OSError as e:
                print("Warning: could not save:", e)
        self._json(200, {"ok": True})

    def log_message(self, *args):
        pass


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Rummy with Friends</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Young+Serif&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{
  --felt:#1c5a3f; --felt-2:#21664a; --felt-3:#2a7656; --felt-deep:#164a33;
  --ink:#f6f1e3; --muted:#c7d8cb; --faint:#9fbcab;
  --card:#fbf7ec; --card-ink:#1d2a22; --card-muted:#6a776e; --red:#c23b2e;
  --brass:#e2b54f; --brass-ink:#2b2109;
  --win:#3ddc8c; --out:#ff7a6e;
  --line:rgba(246,241,227,.16);
  --shadow:0 1px 0 rgba(0,0,0,.18), 0 8px 22px -10px rgba(0,0,0,.5);
  --cw:94px; --ch:134px; --overlap:-44px;
  color-scheme:dark; box-sizing:border-box;
  padding-top:env(safe-area-inset-top,0px); padding-bottom:env(safe-area-inset-bottom,0px);
}
@media (prefers-color-scheme: dark){
  :root:not([data-theme="light"]){ --felt:#0c2b1f; --felt-2:#103727; --felt-3:#164532; --felt-deep:#08201a; --ink:#efe9d8; --muted:#a9c2b2; --faint:#7f9c8b; --card:#f3eddc; --line:rgba(239,233,216,.13); }
}
:root[data-theme="dark"]{ --felt:#0c2b1f; --felt-2:#103727; --felt-3:#164532; --felt-deep:#08201a; --ink:#efe9d8; --muted:#a9c2b2; --faint:#7f9c8b; --card:#f3eddc; --line:rgba(239,233,216,.13); }
html{height:100%}
*,*::before,*::after{box-sizing:border-box}
body{margin:0;min-height:100%;background:var(--felt);
  background-image:radial-gradient(ellipse 110% 70% at 50% 35%, rgba(255,255,255,.07), transparent 65%),radial-gradient(ellipse 90% 60% at 50% 120%, rgba(0,0,0,.3), transparent 60%);
  background-attachment:fixed;color:var(--ink);font-family:Manrope,"Segoe UI",system-ui,sans-serif;font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased}
body::before{content:"";position:fixed;inset:0 0 auto;height:env(safe-area-inset-top,0px);z-index:10;background:var(--felt-deep)}
h1,h2,h3{font-family:"Young Serif",Georgia,serif;font-weight:400;margin:0;line-height:1.15}
button,input{font:inherit;color:inherit}
:focus-visible{outline:2px solid var(--brass);outline-offset:2px}
.num{font-variant-numeric:tabular-nums}
header.top{position:sticky;top:env(safe-area-inset-top,0px);z-index:20;background:var(--felt-deep);border-bottom:1px solid var(--line)}
.top-in{max-width:1100px;margin:0 auto;display:flex;align-items:center;gap:10px;padding:10px 16px}
.logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:inherit;margin-right:auto}
.logo i{font-style:normal;width:26px;height:34px;border-radius:4px;background:var(--card);color:var(--red);display:grid;place-items:center;font-weight:800;font-size:13px;transform:rotate(-8deg)}
.logo b{font-family:"Young Serif",Georgia,serif;font-weight:400;font-size:19px}
main{max-width:1100px;margin:0 auto;padding:18px 16px 140px}
.btn{appearance:none;border:1px solid var(--line);background:rgba(255,255,255,.06);color:var(--ink);padding:10px 16px;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;white-space:nowrap}
.btn:hover{background:rgba(255,255,255,.11)}
.btn:disabled{opacity:.4;cursor:not-allowed}
.btn.primary{background:var(--brass);color:var(--brass-ink);border-color:transparent}
.btn.danger{color:var(--out);border-color:rgba(255,122,110,.45)}
.btn.small{padding:6px 11px;font-size:13px}
.inp{width:100%;background:rgba(0,0,0,.22);border:1px solid var(--line);border-radius:10px;padding:10px 12px;color:var(--ink);outline:none}
.inp:focus{border-color:var(--brass)}
label.f{display:block;font-size:13px;font-weight:600;color:var(--muted);margin-bottom:6px}
.panel{background:var(--felt-2);border:1px solid var(--line);border-radius:16px;padding:20px}
.muted{color:var(--muted)}
.err{color:var(--out);font-size:13.5px;margin-top:8px}
.banner{border:1px dashed var(--line);border-radius:12px;padding:10px 14px;color:var(--muted);font-size:13.5px;margin-bottom:16px}

/* Home */
.home{display:grid;grid-template-columns:1.1fr 1fr;gap:20px;align-items:start}
.home h1{font-size:clamp(32px,5vw,50px);margin:10px 0 12px}
.home .lead{color:var(--muted);font-size:16px;max-width:46ch;margin:0 0 20px}
.stack{display:flex;flex-direction:column;gap:14px}
.row{display:flex;gap:8px;align-items:flex-end}
.code-inp{text-transform:uppercase;letter-spacing:.2em;font-weight:800}
.tlist{display:flex;flex-direction:column;gap:8px;margin-top:6px}
.trow{display:flex;align-items:center;gap:12px;background:rgba(0,0,0,.16);border:1px solid var(--line);border-radius:12px;padding:10px 12px;cursor:pointer;text-align:left;width:100%;color:inherit}
.trow:hover{border-color:rgba(226,181,79,.5)}
.trow .c{font-weight:800;letter-spacing:.16em;font-size:13px}
.trow .n{flex:1;min-width:0;color:var(--muted);font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pill{font-size:12px;font-weight:800;padding:3px 9px;border-radius:999px;background:rgba(255,255,255,.08);color:var(--muted)}
.pill.live{background:rgba(61,220,140,.16);color:var(--win)}
.pill.lobby{background:rgba(226,181,79,.18);color:var(--brass)}
.invites{display:flex;flex-direction:column;gap:8px;margin-bottom:16px}
.invite{display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:rgba(226,181,79,.14);border:1px solid rgba(226,181,79,.5);border-radius:12px;padding:10px 12px}
.invite .t{flex:1;min-width:180px}
.invite .t b{color:var(--brass)}
.invite .x{appearance:none;border:0;background:none;color:var(--muted);font-size:18px;cursor:pointer;padding:2px 6px}

/* Lobby */
.lobby{max-width:560px;margin:10px auto}
.bigcode{font-family:"Young Serif",Georgia,serif;font-size:46px;letter-spacing:.18em;margin:4px 0}
.plist{display:flex;flex-direction:column;gap:6px;margin:14px 0}
.prow{display:flex;align-items:center;gap:10px;background:rgba(0,0,0,.16);border-radius:10px;padding:8px 10px}
.prow .nm{flex:1;font-weight:700}
.chips{display:flex;gap:8px;flex-wrap:wrap}
.chip{appearance:none;border:1px solid var(--line);background:rgba(0,0,0,.18);color:var(--ink);border-radius:999px;padding:7px 14px;font-weight:700;cursor:pointer}
.chip[aria-pressed="true"]{background:var(--brass);color:var(--brass-ink);border-color:transparent}

/* Table */
.tbar{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin-bottom:12px}
.tbar h2{font-size:22px}
.tbar .sp{margin-left:auto;display:flex;gap:8px}
.opps{display:flex;gap:8px;overflow-x:auto;padding:16px 2px 10px;margin:0 -2px}
.opp{position:relative;flex:none;min-width:112px;background:rgba(0,0,0,.2);border:2px solid transparent;border-radius:12px;padding:8px 10px}
.opp .nm{font-weight:800;font-size:14px;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.opp .meta{font-size:12.5px;color:var(--muted)}
.opp.turn{border-color:var(--brass);background:rgba(226,181,79,.12)}
.opp.gone{opacity:.55}
.opp .tag{font-size:11.5px;font-weight:800;color:var(--out)}
.opp.crowned{border-color:rgba(226,181,79,.55)}
.opp.crowned .nm{color:var(--brass)}
.opp.crowned::before{content:"♛";position:absolute;top:-15px;left:50%;transform:translateX(-50%);font-size:22px;line-height:1;color:var(--brass);text-shadow:0 2px 4px rgba(0,0,0,.45)}
.spec{margin-top:16px}
.spec h3{font-size:18px;margin-bottom:4px}
.spec .rrow .who{min-width:140px}
.opp .kick{appearance:none;border:1px solid rgba(255,122,110,.45);background:none;color:var(--out);font-size:11px;font-weight:800;border-radius:999px;padding:1px 8px;margin-top:4px;cursor:pointer}
.rummy{position:fixed;right:max(14px,env(safe-area-inset-right,0px));bottom:calc(118px + env(safe-area-inset-bottom,0px));z-index:16;width:104px;height:104px;border-radius:50%;border:3px solid var(--card);background:radial-gradient(circle at 35% 30%,#6ff3b0,#1f9d5c 70%);color:#04281a;font-family:"Young Serif",Georgia,serif;font-size:19px;letter-spacing:.02em;padding:0;box-shadow:0 12px 28px -6px rgba(0,0,0,.65);cursor:pointer}
.rummy:disabled{filter:grayscale(.75);opacity:.6;cursor:not-allowed}
.opp.me .nm::after{content:" (you)";color:var(--brass);font-weight:700}
.center{display:flex;align-items:center;justify-content:center;gap:22px;padding:18px 10px;margin:6px 0 14px;border-radius:120px/60px;background:rgba(0,0,0,.14);border:1px solid var(--line);flex-wrap:wrap}
.pile{display:flex;flex-direction:column;align-items:center;gap:6px;font-size:12.5px;color:var(--muted);font-weight:600}
.pile .card{cursor:default}
.pile.can .card{cursor:pointer;box-shadow:0 0 0 3px var(--brass),var(--shadow)}
.status{flex-basis:100%;text-align:center;font-weight:700;font-size:15px}
.status.mine{color:var(--brass)}
.last{flex-basis:100%;text-align:center;color:var(--muted);font-size:13px;margin-top:-14px}

.card{position:relative;flex:none;width:var(--cw);height:var(--ch);border-radius:7px;background:var(--card);color:var(--card-ink);border:1px solid rgba(0,0,0,.12);box-shadow:var(--shadow);padding:0;cursor:pointer;appearance:none;text-align:left;transition:transform .12s ease}
.card .rk{position:absolute;top:6px;left:8px;font-weight:800;font-size:26px;line-height:1}
.card .st{position:absolute;top:36px;left:9px;font-size:22px;line-height:1}
.card .big{position:absolute;right:8px;bottom:6px;font-size:46px;line-height:1}
.card.red{color:var(--red)}
.card.pj .big{font-size:17px;font-weight:800;letter-spacing:.04em;bottom:10px}
.card.wild::after{content:"★";position:absolute;left:8px;top:62px;font-size:20px;color:#b8860b}
.card.back{background:repeating-linear-gradient(45deg,#8c2a22 0 5px,#a3352b 5px 10px);border:3px solid var(--card)}
.card.sel{transform:translateY(-14px);box-shadow:0 0 0 3px var(--brass),var(--shadow)}
.card.fresh{outline:2px dashed var(--brass);outline-offset:2px}
.card.sm{--cw:34px;--ch:48px;width:34px;height:48px;cursor:default;border-radius:5px}
.card.sm .rk{font-size:11px;top:3px;left:3px}.card.sm .st{top:15px;left:3px;font-size:10px}.card.sm .big{display:none}
.card.sm.pj .big{display:block;font-size:7px;bottom:4px;right:3px}
.card.sm.wild::after{font-size:8px;left:3px;top:27px}

.hand{display:flex;flex-wrap:wrap;gap:22px 18px;padding:18px 4px 6px;justify-content:center}
.grp{display:flex;flex-direction:column;align-items:center;gap:6px;border-radius:12px;padding:4px 4px 2px}
.grp .cards{display:flex;padding-left:calc(-1 * var(--overlap))}
.grp .cards .card{margin-left:var(--overlap)}
.grp .lab{font-size:12px;font-weight:800;padding:2px 9px;border-radius:999px;background:rgba(0,0,0,.25);color:var(--muted);display:flex;gap:6px;align-items:center}
.grp .lab.pure,.grp .lab.japan{background:rgba(61,220,140,.2);color:var(--win)}
.grp .lab.seq{background:rgba(120,200,255,.18);color:#9fd8ff}
.grp .lab.set{background:rgba(226,181,79,.2);color:var(--brass)}
.grp .lab.none{color:var(--faint)}
.grp .lab.extra{background:rgba(255,122,110,.18);color:var(--out)}
.movehere{appearance:none;border:1px dashed var(--brass);background:transparent;color:var(--brass);font-size:11.5px;font-weight:800;border-radius:999px;padding:2px 9px;cursor:pointer}
.hand-pts{text-align:center;color:var(--muted);font-size:13px}
.pile.wildc .card{box-shadow:0 0 0 3px #b8860b,var(--shadow)}
.pile.wildc .card.back{display:grid;place-items:center;color:var(--card);font-family:"Young Serif",Georgia,serif;font-size:26px}
.pile.wildc .wl{max-width:130px;text-align:center;line-height:1.3}
.cust{display:flex;gap:6px;align-items:center}
.cust .inp{width:96px;padding:6px 10px;border-radius:999px}

.actions{position:fixed;left:0;right:0;bottom:0;z-index:15;background:var(--felt-deep);border-top:1px solid var(--line);padding:10px 12px calc(10px + env(safe-area-inset-bottom,0px))}
.actions .in{max-width:1100px;margin:0 auto;display:flex;gap:8px;flex-wrap:wrap;justify-content:center;align-items:center}
.actions .hint{flex-basis:100%;text-align:center;font-size:12.5px;color:var(--muted)}

/* Results & scores */
.result{border:1px solid rgba(226,181,79,.45);background:linear-gradient(180deg,rgba(226,181,79,.12),rgba(0,0,0,.1));border-radius:16px;padding:18px;margin-bottom:16px}
.result h2{font-size:24px;margin-bottom:4px}
.rrow{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;padding:10px 0;border-top:1px solid var(--line)}
.rrow .who{min-width:120px;font-weight:800}
.rrow .p{min-width:70px;font-family:"Young Serif",Georgia,serif;font-size:20px}
.rrow .p.zero{color:var(--win)}
.rrow .why{font-size:12.5px;color:var(--muted);min-width:110px}
.rgroups{display:flex;flex-wrap:wrap;gap:10px}
.rgroups .g{display:flex;gap:2px;padding:3px;border-radius:7px}
.rgroups .g.bad{background:rgba(255,122,110,.18)}
.champ{text-align:center;padding:26px 16px}
.champ .crown{font-size:44px;color:var(--brass)}
.champ h2{font-size:34px;color:var(--win);margin:6px 0}
.sbw{overflow-x:auto;border:1px solid var(--line);border-radius:12px;background:rgba(0,0,0,.14);margin-top:8px}
table.sb{border-collapse:collapse;width:100%;min-width:max-content;font-size:14px}
.sb th,.sb td{padding:8px 10px;text-align:right;border-bottom:1px solid var(--line);white-space:nowrap}
.sb th{background:var(--felt-3);font-size:13px}
.sb th:first-child,.sb td:first-child{text-align:left;position:sticky;left:0;background:var(--felt-2);font-weight:700}
.sb th:first-child{background:var(--felt-3)}
.sb tfoot td{font-weight:800;font-size:15px}
.sb .low{color:var(--win)}.sb .out{color:var(--out)}
.sb .zero{color:var(--win)}
dialog{border:0;border-radius:16px;background:var(--felt-2);color:var(--ink);padding:22px;max-width:440px;width:calc(100% - 32px);box-shadow:0 20px 60px rgba(0,0,0,.5)}
dialog::backdrop{background:rgba(0,0,0,.55)}
dialog h3{font-size:21px;margin-bottom:8px}
dialog p{color:var(--muted);margin:0 0 18px}
dialog .r{display:flex;justify-content:flex-end;gap:8px}
.toast{position:fixed;left:50%;bottom:calc(96px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);background:var(--card);color:var(--card-ink);padding:10px 16px;border-radius:10px;font-weight:700;box-shadow:var(--shadow);z-index:50;max-width:90vw;text-align:center}
.toast.bad{background:#ffe1dc;color:#7d1d14}
.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.loading{padding:80px 0;text-align:center;color:var(--muted)}
details.how{margin-top:16px;color:var(--muted);font-size:14px}
details.how summary{cursor:pointer;font-weight:700;color:var(--ink)}
details.how ul{padding-left:18px;margin:8px 0 0}
@media (max-width:820px){ .home{grid-template-columns:1fr} }
@media (max-width:560px){
  :root{--cw:68px;--ch:98px;--overlap:-34px}
  .card.wild::after{top:46px;left:6px;font-size:14px}
  main{padding:12px 10px 150px}
  .card .rk{font-size:20px;top:5px;left:6px}.card .st{top:28px;left:7px;font-size:16px}.card .big{font-size:32px}
  .card.pj .big{font-size:13px}
  .hand{gap:18px 8px;padding:16px 0 6px}
  .center{gap:14px;padding:12px 8px}
  .logo b{font-size:17px}
  .rummy{width:84px;height:84px;font-size:15px;letter-spacing:0;bottom:calc(128px + env(safe-area-inset-bottom,0px))}
}
@media (prefers-reduced-motion: reduce){ *{transition:none !important;animation:none !important} }
</style>
</head>
<body>
<header class="top"><div class="top-in">
  <a class="logo" href="#"><i>A♥</i><b>Rummy with Friends</b></a>
  <span id="hdr"></span>
</div></header>
<main id="app"><div class="loading">Shuffling the decks…</div></main>
<div id="bar"></div>
<dialog id="dlg"><h3 id="dlg-t"></h3><p id="dlg-p"></p><div class="r"><button class="btn" id="dlg-no">Cancel</button><button class="btn primary" id="dlg-yes">OK</button></div></dialog>
<script>
"use strict";
/* ================= Rules ================= */
const RANKS = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
const SUIT = {S:"♠", H:"♥", D:"♦", C:"♣"};
const HAND_SIZE = 13, JOKERS_PER_DECK = 3;
const DEFAULTS = {maxScore:101, firstDrop:20, middleDrop:40, fullCount:80, jokerMode:"open"};
const MAX_PRESETS = [101, 201, 240], MAX_MIN = 50, MAX_MAX = 2000;
function decksFor(n){ return n >= 2 && n <= 6 ? 3 : n >= 7 && n <= 10 ? 5 : 0; }
function makeShoe(decks){
  const c = [];
  for (let d = 1; d <= decks; d++){
    for (const s of "SHDC") for (const r of RANKS) c.push(r + s + d);
    for (const x of "abc".slice(0, JOKERS_PER_DECK)) c.push("PJ" + d + x);
  }
  return c;
}
function shuffle(a){
  const r = new Uint32Array(a.length); crypto.getRandomValues(r);
  for (let i = a.length - 1; i > 0; i--){ const j = r[i] % (i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function parse(id){
  if (id.startsWith("PJ")) return {pj:true, rank:null, suit:null};
  const m = id.match(/^(10|[A2-9JQK])([SHDC])\d+$/);
  return {pj:false, rank:m[1], suit:m[2]};
}
const rv = r => RANKS.indexOf(r) + 1;
function isWild(id, wild){ const c = parse(id); return c.pj || c.rank === wild; }
function cardPts(id, wild){ if (isWild(id, wild)) return 0; const r = parse(id).rank; return ["A","J","Q","K"].includes(r) ? 10 : Number(r); }
function fits(vals, jokers){
  if (!vals.length || new Set(vals).size !== vals.length) return false;
  const s = vals.slice().sort((a,b) => a - b);
  return (s[s.length-1] - s[0] + 1 - s.length) <= jokers && s.length + jokers <= 14;
}
function seqOk(vals, jokers){ return fits(vals, jokers) || (vals.includes(1) && fits(vals.map(v => v === 1 ? 14 : v), jokers)); }
/* Kind of a group: pure sequence, sequence (with jokers), set, or none */
function classify(g, wild){
  if (g.length < 3) return "none";
  const cs = g.map(parse);
  if (cs.every(c => !c.pj) && cs.every(c => c.suit === cs[0].suit)){
    if (cs.every(c => c.rank === cs[0].rank)) return "japan";  // 3+ identical cards: counts as a pure sequence
    if (seqOk(cs.map(c => rv(c.rank)), 0)) return "pure";
  }
  const nat = g.filter(id => !isWild(id, wild)).map(parse), j = g.length - nat.length;
  if (!nat.length) return "set";
  if (nat.every(c => c.suit === nat[0].suit) && seqOk(nat.map(c => rv(c.rank)), j)) return "seq";
  if (g.length <= 4 && nat.every(c => c.rank === nat[0].rank) && new Set(nat.map(c => c.suit)).size === nat.length) return "set";
  return "none";
}
const isPure = k => k === "pure" || k === "japan";
/* Only one set counts in a hand; any further set is marked "extra" and isn't a meld */
const MAX_SETS = 1;
const isMeld = k => k !== "none" && k !== "extra";
function evalHand(groups, wild){
  let sets = 0;
  const kinds = groups.map(g => classify(g, wild)).map(k => k === "set" && ++sets > MAX_SETS ? "extra" : k);
  const pure = kinds.filter(isPure).length, seqs = kinds.filter(k => isPure(k) || k === "seq").length;
  return {kinds, pure, seqs, extra: sets > MAX_SETS, valid: kinds.every(isMeld) && pure >= 1 && seqs >= 2};
}
function handPoints(groups, wild, cap){
  const e = evalHand(groups, wild); let s = 0;
  groups.forEach((g, i) => {
    // every valid group (pure, Japan, sequence, the one motta) is free; only loose cards count
    if (!isMeld(e.kinds[i])) g.forEach(id => s += cardPts(id, wild));
  });
  return Math.min(s, cap);
}
/* Pull every Japan and pure run (3+ in a row, same suit) out of the cards as its own group */
function pureRuns(cards){
  const runs = [], same = {};
  cards.forEach(id => (same[id.replace(/\d+$/, "")] = same[id.replace(/\d+$/, "")] || []).push(id));
  Object.values(same).forEach(ids => { if (ids.length >= 3) runs.push(ids); });
  let rest = cards.filter(id => !runs.some(r => r.includes(id)));
  for (const suit of "SHCD"){
    for (;;){
      const at = {};
      rest.forEach(id => { const c = parse(id); if (c.suit === suit){ const v = rv(c.rank); at[v] = at[v] || id; if (v === 1) at[14] = at[14] || id; } });
      let best = [];
      for (let v = 1, cur = []; v <= 15; v++){
        if (at[v] && !(v === 14 && cur.includes(at[14]))) cur.push(at[v]);
        else { if (cur.length > best.length) best = cur; cur = at[v] ? [at[v]] : []; }
      }
      if (best.length < 3) break;
      runs.push(best); rest = rest.filter(id => !best.includes(id));
    }
  }
  return {runs, rest};
}
function autoGroup(cards, wild){
  const {runs, rest} = pureRuns(cards.filter(id => !parse(id).pj));
  const by = {S:[], H:[], C:[], D:[], J:cards.filter(id => parse(id).pj)};
  rest.forEach(id => { const c = parse(id); (isWild(id, wild) ? by.J : by[c.suit]).push(id); });
  const ord = id => rv(parse(id).rank) || 0;
  return runs.concat(["S","H","C","D","J"].map(k => by[k].sort((a,b) => ord(a) - ord(b))).filter(g => g.length));
}
const KIND_LABEL = {pure:"Pure sequence", japan:"Japan", seq:"Sequence", set:"Motta", none:"Not a meld", extra:"Only 1 motta allowed"};

/* ================= Platform & state ================= */
const S = {db:null, me:null, isOwner:false, list:[], listLoaded:false, game:null, gameLoaded:false, gameCode:null, stale:false};
const ui = {name:"", code:"", err:"", sel:[], showScores:false, busy:false, joinName:"", customMax:"", dismissed:[]};
const INVITE_MINUTES = 15, RECENT_MINUTES = 30;
let announced = null;
function lsGet(k){ try { return localStorage.getItem(k); } catch { return null; } }
function lsSet(k, v){ try { localStorage.setItem(k, v); } catch {} }
ui.name = lsGet("rummy-name") || "";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const CODE_CHARS = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const makeCode = () => Array.from({length:5}, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join("");
const clone = o => JSON.parse(JSON.stringify(o));

let chain = Promise.resolve();
function write(code, op){
  chain = chain.then(() => op(S.db.doc("games/" + code))).catch(e => {
    if (e && e.code === "invalid_argument") toast("That move wasn’t saved. You may only have view access to this page.", true);
    else if (e && e.code === "quota_exceeded") toast("Storage is full. Ask the owner to clear old tables.", true);
    else toast("Couldn’t reach the table. Check your connection and try again.", true);
  });
  return chain;
}
const upd = (patch) => write(S.game.id, ref => ref.update(patch));

let unsubList = null, unsubGame = null;
function route(){ const h = location.hash.slice(1); return h.startsWith("t-") ? {view:"table", code:h.slice(2)} : {view:"home"}; }
function syncSubs(){
  if (!S.db) return;
  const r = route();
  if (!unsubList){
    unsubList = S.db.collection("games").orderBy("createdAt","desc").limit(25).onSnapshot(snap => {
      S.list = snap.docs.filter(d => d.exists).map(d => Object.assign({id:d.id}, d.data())); S.listLoaded = true;
      announceInvites(); render();
    }, () => { S.listLoaded = true; render(); });
  }
  if (r.view === "table" && S.gameCode !== r.code){
    if (unsubGame) unsubGame();
    S.gameCode = r.code; S.game = null; S.gameLoaded = false; ui.sel = [];
    const timer = setTimeout(() => { S.stale = true; S.gameLoaded = true; render(); }, 10000);
    unsubGame = S.db.doc("games/" + r.code).onSnapshot(s => {
      if (!s.metadata.fromCache){ clearTimeout(timer); S.stale = false; }
      S.game = s.exists ? Object.assign({id:s.id}, s.data()) : null; S.gameLoaded = true; render();
    }, () => { clearTimeout(timer); S.gameLoaded = true; S.stale = true; render(); });
  }
  if (r.view !== "table" && unsubGame){ unsubGame(); unsubGame = null; S.gameCode = null; S.game = null; }
}
window.addEventListener("hashchange", () => { ui.err = ""; ui.showScores = false; syncSubs(); render(); window.scrollTo(0,0); });

async function boot(){
  let db = null, user = null;
  if (window.claude && typeof window.claude.use === "function"){
    const safe = p => Promise.resolve(p).catch(() => null);
    [db, user] = await Promise.all([safe(claude.use("db")), safe(claude.use("user"))]);
  }
  if (user){ S.me = await user.id().catch(() => null); S.isOwner = await user.isOwner().catch(() => false); }
  if (!S.me){ S.me = lsGet("rummy-device"); if (!S.me){ S.me = "d" + Math.random().toString(36).slice(2,10); lsSet("rummy-device", S.me); } }
  S.db = db || httpDB(); S.ready = true;
  syncSubs(); render();
}


/* ===== Shared table over this server (polling) ===== */
function httpDB(){
  const ticks = new Set();
  const api = async (url, opts) => { const r = await fetch(url, opts); if (!r.ok) throw {code: r.status === 400 ? "invalid_argument" : "unavailable"}; return r.json(); };
  const post = (code, body) => api("/api/game/" + code, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)}).then(res => { ticks.forEach(t => t()); return res; });
  function watch(fetcher, deliver, onErr){
    let last = null, stop = false, timer = null, fails = 0;
    const tick = async () => {
      clearTimeout(timer); if (stop) return;
      try { const v = await fetcher(); fails = 0; const s = JSON.stringify(v); if (s !== last){ last = s; deliver(v); } }
      catch { if (++fails === 8 && onErr) onErr({code:"unavailable"}); }
      if (!stop) timer = setTimeout(tick, document.hidden ? 4000 : 900);
    };
    ticks.add(tick); tick();
    return () => { stop = true; clearTimeout(timer); ticks.delete(tick); };
  }
  const doc = path => {
    const code = path.split("/")[1];
    return {
      set: data => post(code, {op:"set", data}),
      update: data => post(code, {op:"update", data}),
      delete: () => post(code, {op:"delete"}),
      onSnapshot(next, err){
        return watch(() => api("/api/game/" + code), v => next({id:code, exists:!!v.exists, data:() => v.data, metadata:{fromCache:false}}), err);
      }
    };
  };
  const collection = () => { const q = {orderBy:() => q, limit:() => q,
    onSnapshot(next, err){ return watch(() => api("/api/games"), v => next({docs:v.map(g => ({id:g.id, exists:true, data:() => g}))}), err); } }; return q; };
  return {doc, collection};
}

/* ================= Derived game info ================= */
function seats(g){ return Object.entries(g.players || {}).filter(([,p]) => p && p.name).map(([id,p]) => ({id, name:p.name, order:p.order || 0, left:!!p.left})).sort((a,b) => a.order - b.order); }
function nameOf(g, id){ return (g.players && g.players[id] && g.players[id].name) || "Someone"; }
function curDeal(g){ return g.cur ? g.deals && g.deals["d" + g.cur] : null; }
function settings(g){ return Object.assign({}, DEFAULTS, g.settings || {}); }
function totals(g){
  const t = {}; seats(g).forEach(p => t[p.id] = 0);
  const list = Object.values(g.deals || {}).filter(d => d.status === "done").sort((a,b) => a.n - b.n);
  list.forEach(d => Object.entries(d.result.scores).forEach(([pid, v]) => t[pid] = (t[pid] || 0) + v));
  return {t, list};
}
function activeIds(g){ const {t} = totals(g), max = settings(g).maxScore; return seats(g).filter(p => !p.left && t[p.id] < max).map(p => p.id); }
/* Hidden joker: a player sees the wild card only after making a pure sequence */
function revealed(d, pid){ return !d.hidden || d.status === "done" || !!(d.seen && d.seen[pid]); }
function spectating(g, d){ const p = g.players && g.players[S.me]; return !!(p && p.name && !p.left && !d.players.includes(S.me) && totals(g).t[S.me] >= settings(g).maxScore); }
/* Players out of this deal (dropped, wrong show) or out of the game on points also see the wild joker */
function viewWild(d){ return revealed(d, S.me) || (d.out && d.out[S.me]) || (S.game && spectating(S.game, d)) ? d.wild : null; }
const hasPureGroup = groups => groups.some(g => isPure(classify(g, null)));
const missedJoker = (d, p) => !!d.hidden && !(d.seen && d.seen[p]);
function seenPatch(d, groups){
  if (revealed(d, S.me) || !hasPureGroup(groups)) return {};
  toast(`Pure sequence made. The wild joker is ${label(d.cut).replace("a joker", "the printed joker")}, so every ${d.wild} is wild.`);
  return {seen:{[S.me]:true}};
}
/* Tables someone is hosting that I could join, and tables I'm already seated at */
function isSeated(g){ const p = g.players && g.players[S.me]; return !!(p && p.name && !p.left); }
const lastActive = g => g.updatedAt || g.createdAt || 0;
function newestOfHost(g){ return !S.list.some(x => x.host === g.host && x.createdAt > g.createdAt); }
function invites(){
  const since = Date.now() - INVITE_MINUTES * 60000;
  return S.list.filter(g => g.status === "lobby" && g.host !== S.me && !isSeated(g) && lastActive(g) > since && newestOfHost(g) && !ui.dismissed.includes(g.id) && seats(g).length < 10);
}
function myTables(){
  const since = Date.now() - RECENT_MINUTES * 60000;
  return S.list.filter(g => g.status !== "over" && isSeated(g) && lastActive(g) > since);
}
function announceInvites(){
  const ids = invites().map(g => g.id);
  if (announced && route().view === "home") ids.filter(id => !announced.has(id)).forEach(id => {
    const g = S.list.find(x => x.id === id); toast(`${nameOf(g, g.host)} is hosting table ${id}. Tap Join to play.`);
  });
  announced = new Set(ids);
}
function nextTurn(d, out, from){
  const ps = d.players, i = ps.indexOf(from);
  for (let k = 1; k <= ps.length; k++){ const p = ps[(i + k) % ps.length]; if (!out[p]) return p; }
  return from;
}

/* ================= Game actions ================= */
function newDeal(g, n){
  const pids = activeIds(g);
  const shoe = shuffle(makeShoe(decksFor(seats(g).length)));
  const cut = shoe.pop();
  const wild = parse(cut).pj ? "A" : parse(cut).rank;
  shoe.unshift(cut);
  const hidden = settings(g).jokerMode === "hidden", hands = {}, seen = {};
  pids.forEach(p => {
    hands[p] = autoGroup(shoe.splice(shoe.length - HAND_SIZE, HAND_SIZE), hidden ? null : wild);
    if (hidden && hasPureGroup(hands[p])) seen[p] = true;
  });
  const di = (n - 1) % pids.length;
  return {n, players:pids, dealer:pids[di], cut, wild, hidden, seen, stock:shoe, discard:[shoe.pop()], hands,
    turn:pids[(di + 1) % pids.length], turnAt:Date.now(), phase:"draw", drawn:{}, out:{}, pen:{}, status:"live", last:`Deal ${n}: cards are dealt.`, fresh:{}, at:Date.now()};
}
function finishPatch(g, d, winner, how, extra){
  const st = settings(g), scores = {};
  const out = Object.assign({}, d.out, extra.out || {}), pen = Object.assign({}, d.pen, extra.pen || {});
  const hands = Object.assign({}, d.hands, extra.hands || {});
  d.players.forEach(p => { scores[p] = pen[p] != null ? pen[p] : p === winner ? 0 : missedJoker(d, p) ? st.fullCount : handPoints(hands[p] || [], d.wild, st.fullCount); });
  const dealPatch = Object.assign({}, extra, {status:"done", result:{winner, how, scores}});
  // check whether the game is over after these scores
  const {t} = totals(g); const max = st.maxScore;
  Object.entries(scores).forEach(([p,v]) => t[p] = (t[p] || 0) + v);
  const patch = {deals:{["d" + d.n]: dealPatch}};
  return Object.assign(patch, overPatch(g, t));
}
/* Game ends when one player (not out, not left) remains */
function overPatch(g, t){
  const max = settings(g).maxScore, stay = seats(g).filter(p => !p.left), alive = stay.filter(p => t[p.id] < max);
  if (alive.length > 1) return {};
  const champ = alive[0] || (stay.length ? stay : seats(g)).slice().sort((a,b) => t[a.id] - t[b.id])[0];
  return {status:"over", champion:champ.id, endedAt:Date.now()};
}
/* A player leaves (or the host removes them) mid-game: they take a drop penalty for a live deal */
function leavePatch(g, pid, self){
  const g2 = clone(g); g2.players[pid].left = true;
  const patch = {players:{[pid]:{left:true}}};
  if (g.host === pid){ const nh = seats(g2).find(p => !p.left); if (nh) patch.host = nh.id; }
  const d = curDeal(g), st = settings(g), who = nameOf(g, pid);
  if (d && d.status === "live" && d.players.includes(pid) && !d.out[pid]){
    const amt = d.drawn && d.drawn[pid] ? st.middleDrop : st.firstDrop;
    const extra = {out:{[pid]:"left"}, pen:{[pid]:amt}, last:self ? `${who} left the table (+${amt}).` : `The host removed ${who} (+${amt}).`};
    const out = Object.assign({}, d.out, extra.out), rest = d.players.filter(p => !out[p]);
    if (rest.length === 1) return Object.assign(patch, finishPatch(g2, d, rest[0], "last", Object.assign(extra, {last:extra.last + ` ${nameOf(g, rest[0])} wins the deal.`})));
    return Object.assign(patch, {deals:{["d" + d.n]: Object.assign(extra, d.turn === pid ? {turn:nextTurn(d, out, pid), turnAt:Date.now(), phase:"draw"} : {})}});
  }
  return g.status === "playing" ? Object.assign(patch, overPatch(g2, totals(g2).t)) : patch;
}
function afterOut(g, d, extra){
  const out = Object.assign({}, d.out, extra.out);
  const left = d.players.filter(p => !out[p]);
  if (left.length === 1) return finishPatch(g, d, left[0], "last", Object.assign({}, extra, {last: extra.last + ` ${nameOf(g, left[0])} wins the deal.`}));
  return {deals:{["d" + d.n]: Object.assign({}, extra, {turn: nextTurn(d, out, d.turn), turnAt:Date.now(), phase:"draw"})}};
}
const A = {
  async create(){
    const name = ui.name.trim();
    if (!name) { ui.err = "Enter your name first."; return render(); }
    lsSet("rummy-name", name);
    let code; do { code = makeCode(); } while (S.list.some(g => g.id === code));
    S.list.filter(g => g.host === S.me && g.status === "lobby").forEach(g => write(g.id, ref => ref.delete()));
    await write(code, ref => ref.set({createdAt:Date.now(), host:S.me, status:"lobby", players:{[S.me]:{name, order:Date.now()}}, settings:Object.assign({}, DEFAULTS), deals:{}, cur:0}));
    location.hash = "t-" + code;
  },
  join(){
    const c = ui.code.trim().toUpperCase();
    if (!/^[A-Z0-9]{5}$/.test(c)) { ui.err = "Table codes are 5 letters or numbers."; return render(); }
    ui.err = ""; location.hash = "t-" + c;
  },
  open(d){ location.hash = "t-" + d.code; },
  dismiss(d){ ui.dismissed.push(d.code); render(); },
  async sit(){
    const g = S.game, name = (ui.joinName || ui.name).trim();
    if (!name) { ui.err = "Enter your name to take a seat."; return render(); }
    if (seats(g).some(p => p.id !== S.me && p.name.toLowerCase() === name.toLowerCase())) { ui.err = `${name} is already at this table. Use a different name.`; return render(); }
    if (seats(g).length >= 10) { ui.err = "This table is full."; return render(); }
    ui.err = ""; lsSet("rummy-name", name); ui.name = name;
    await upd({players:{[S.me]:{name, order:Date.now()}}});
  },
  async leave(d){ await upd({players:{[d.pid || S.me]: null}}); },
  async quit(dd){
    const g = S.game, pid = dd.pid || S.me, self = pid === S.me;
    if (!g.players[pid] || g.players[pid].left) return;
    const d = curDeal(g), live = d && d.status === "live" && d.players.includes(pid) && !d.out[pid];
    const amt = live ? (d.drawn && d.drawn[pid] ? settings(g).middleDrop : settings(g).firstDrop) : 0;
    const msg = (self ? "You’ll be out of this game" : `${nameOf(g, pid)} will be out of this game`) + (live ? ` and get ${amt} points for this deal.` : ".") + " Scores so far stay on the scoreboard.";
    if (!(await confirmBox(self ? "Leave the game?" : `Remove ${nameOf(g, pid)}?`, msg, self ? "Leave" : "Remove"))) return;
    ui.sel = [];
    await busy(() => upd(leavePatch(g, pid, self)));
    if (self) location.hash = "";
  },
  async max(d){ await upd({settings:{maxScore:Number(d.v)}}); },
  async customMax(){
    const v = Number(ui.customMax);
    if (!Number.isInteger(v) || v < MAX_MIN || v > MAX_MAX) { ui.err = `Pick a whole number from ${MAX_MIN} to ${MAX_MAX}.`; return render(); }
    ui.err = ""; ui.customMax = ""; await upd({settings:{maxScore:v}});
  },
  async joker(d){ await upd({settings:{jokerMode:d.v}}); },
  async start(){
    const g = S.game; if (seats(g).length < 2) return toast("You need at least 2 players.", true);
    await upd({status:"playing", startedAt:Date.now(), cur:1, deals:{d1: newDeal(g, 1)}});
  },
  async nextDeal(){
    const g = S.game, d = curDeal(g); if (!d || d.status !== "done" || g.status !== "playing") return;
    const n = d.n + 1; await upd({cur:n, deals:{["d" + n]: newDeal(g, n)}});
  },
  sel(dd){
    const i = ui.sel.indexOf(dd.id);
    if (i >= 0) ui.sel.splice(i, 1); else ui.sel.push(dd.id);
    render();
  },
  async drawStock(){
    const g = S.game, d = curDeal(g); if (!myTurn(d, "draw") || ui.busy) return;
    let stock = d.stock.slice(), discard = d.discard.slice(), note = "";
    if (!stock.length){ const top = discard.pop(); stock = shuffle(discard); discard = [top]; note = " The discard pile was reshuffled into the stock."; }
    const card = stock.pop(); const groups = clone(d.hands[S.me]); groups.push([card]);
    await busy(() => upd({deals:{["d" + d.n]:{stock, discard, hands:{[S.me]:groups}, phase:"discard", drawn:{[S.me]:true}, fresh:{[S.me]:card}, last:`${nameOf(g,S.me)} drew from the stock.${note}`}}}));
  },
  async drawDiscard(){
    const g = S.game, d = curDeal(g); if (!myTurn(d, "draw") || ui.busy) return;
    const discard = d.discard.slice(), card = discard.pop();
    if (!card) return;
    const groups = clone(d.hands[S.me]); groups.push([card]);
    await busy(() => upd({deals:{["d" + d.n]:{discard, hands:{[S.me]:groups}, phase:"discard", drawn:{[S.me]:true}, fresh:{[S.me]:card}, last:`${nameOf(g,S.me)} picked up ${label(card)}.`}}}));
  },
  async group(){
    const g = S.game, d = curDeal(g); if (!d || !d.hands[S.me] || !ui.sel.length) return;
    const groups = clone(d.hands[S.me]).map(gr => gr.filter(id => !ui.sel.includes(id))).filter(gr => gr.length);
    groups.push(ui.sel.slice()); ui.sel = [];
    await upd({deals:{["d" + d.n]:{hands:{[S.me]:groups}}}});
  },
  async moveTo(dd){
    const g = S.game, d = curDeal(g); if (!d || !ui.sel.length) return;
    const idx = Number(dd.i), src = clone(d.hands[S.me]); const target = src[idx];
    const groups = src.map((gr, i) => i === idx ? gr : gr.filter(id => !ui.sel.includes(id)));
    groups[idx] = target.filter(id => !ui.sel.includes(id)).concat(ui.sel);
    ui.sel = []; const kept = groups.filter(gr => gr.length);
    await upd({deals:{["d" + d.n]:{hands:{[S.me]:kept}}}});
  },
  async sort(){
    const g = S.game, d = curDeal(g); if (!d || !d.hands[S.me]) return;
    ui.sel = []; const groups = autoGroup(d.hands[S.me].flat(), viewWild(d));
    await upd({deals:{["d" + d.n]:{hands:{[S.me]:groups}}}});
  },
  async discard(){
    const g = S.game, d = curDeal(g); if (!myTurn(d, "discard") || ui.busy) return;
    if (ui.sel.length !== 1) return toast("Select exactly one card to discard.", true);
    const card = ui.sel[0]; ui.sel = [];
    const groups = clone(d.hands[S.me]).map(gr => gr.filter(id => id !== card)).filter(gr => gr.length);
    await busy(() => upd({deals:{["d" + d.n]:{...seenPatch(d, groups), hands:{[S.me]:groups}, discard:d.discard.concat([card]), turn:nextTurn(d, d.out, S.me), turnAt:Date.now(), phase:"draw", fresh:{[S.me]:null}, last:`${nameOf(g,S.me)} discarded ${label(card)}.`}}}));
  },
  async declare(){
    const g = S.game, d = curDeal(g); if (!myTurn(d, "discard") || ui.busy) return;
    if (ui.sel.length !== 1) return toast("Select the one card you’ll close with, then tap RUMMY.", true);
    const card = ui.sel[0];
    const groups = clone(d.hands[S.me]).map(gr => gr.filter(id => id !== card)).filter(gr => gr.length);
    const ev = evalHand(groups, d.wild), st = settings(g);
    const msg = ev.valid ? "Your groups look valid. Calling Rummy ends this deal with 0 points for you."
      : `Your groups aren’t a valid show yet (${ev.pure ? "" : "no pure sequence, "}${ev.seqs < 2 ? "need 2 sequences, " : ""}${ev.extra ? "only 1 motta is allowed, " : ""}${ev.kinds.includes("none") ? "some groups aren’t melds" : ""}`.replace(/, $/, "") + `). A wrong show costs ${st.fullCount} points and you’re out of this deal.`;
    if (!(await confirmBox(ev.valid ? "Call Rummy and win?" : "Call Rummy anyway?", msg, "Rummy!"))) return;
    ui.sel = [];
    const base = {hands:{[S.me]:groups}, discard:d.discard.concat([card]), fresh:{[S.me]:null}};
    if (ev.valid){
      await busy(() => upd(finishPatch(g, d, S.me, "declare", Object.assign(base, {last:`${nameOf(g,S.me)} called Rummy and won the deal.`}))));
    } else {
      await busy(() => upd(afterOut(g, d, Object.assign(base, {out:{[S.me]:"wrong"}, pen:{[S.me]:st.fullCount}, last:`${nameOf(g,S.me)} made a wrong show (+${st.fullCount}).`}))));
    }
  },
  async drop(dd){
    const g = S.game, d = curDeal(g), who = dd.pid || S.me;
    if (!d || d.status !== "live" || d.turn !== who || ui.busy) return;
    const st = settings(g), amt = d.drawn && d.drawn[who] ? st.middleDrop : st.firstDrop;
    const forced = who !== S.me;
    if (!(await confirmBox(forced ? `Drop ${nameOf(g, who)}?` : "Drop this deal?", `${forced ? nameOf(g, who) + " gets" : "You get"} ${amt} points and sit out the rest of this deal.`, "Drop"))) return;
    ui.sel = [];
    await busy(() => upd(afterOut(g, d, {out:{[who]:"drop"}, pen:{[who]:amt}, last:`${nameOf(g, who)} dropped (+${amt}).`})));
  },
  scores(){ ui.showScores = !ui.showScores; render(); if (ui.showScores) setTimeout(() => document.getElementById("scores")?.scrollIntoView({behavior:"smooth", block:"start"}), 30); },
  async again(){
    const g = S.game; let code; do { code = makeCode(); } while (S.list.some(x => x.id === code));
    const players = {}; seats(g).forEach((p,i) => players[p.id] = {name:p.name, order:Date.now() + i});
    await write(code, ref => ref.set({createdAt:Date.now(), host:S.me, status:"lobby", players, settings:settings(g), deals:{}, cur:0}));
    await upd({next:code}); location.hash = "t-" + code;
  },
  async del(){
    if (!(await confirmBox("Close this table?", "It’s removed for everyone at the table.", "Close table"))) return;
    const code = S.game.id; await write(code, ref => ref.delete()); location.hash = "";
  }
};
function myTurn(d, phase){ return d && d.status === "live" && d.turn === S.me && d.phase === phase; }
async function busy(fn){ ui.busy = true; try { await fn(); } finally { ui.busy = false; render(); } }
function label(id){ const c = parse(id); return c.pj ? "a joker" : c.rank + SUIT[c.suit]; }

/* ================= Rendering ================= */
const app = document.getElementById("app"), bar = document.getElementById("bar");
function cardHTML(id, wild, o = {}){
  const c = parse(id), w = wild && isWild(id, wild);
  const cls = ["card", o.sm ? "sm" : "", c.pj ? "pj red" : (c.suit === "H" || c.suit === "D") ? "red" : "", w ? "wild" : "", o.sel ? "sel" : "", o.fresh ? "fresh" : ""].join(" ");
  const inner = c.pj ? `<span class="rk">★</span><span class="big">JOKER</span>` : `<span class="rk">${c.rank}</span><span class="st">${SUIT[c.suit]}</span><span class="big">${SUIT[c.suit]}</span>`;
  const aria = c.pj ? "Printed joker" : `${c.rank} of ${({S:"spades",H:"hearts",D:"diamonds",C:"clubs"})[c.suit]}${w ? ", joker" : ""}`;
  return o.act ? `<button class="${cls}" ${o.act} aria-label="${aria}" aria-pressed="${!!o.sel}">${inner}</button>` : `<span class="${cls}" role="img" aria-label="${aria}">${inner}</span>`;
}
function render(){
  const a = document.activeElement, fk = a && a.dataset ? a.dataset.focus : null;
  document.getElementById("hdr").innerHTML = "";
  bar.innerHTML = "";
  if (!S.ready){ app.innerHTML = `<div class="loading">Shuffling the decks…</div>`; return; }
  if (!S.db){ app.innerHTML = `<div class="panel" style="max-width:560px;margin:40px auto"><h2>Open this from its claude.ai link</h2><p class="muted">Playing with friends needs the shared table, which only works when this page is opened on claude.ai. Share the page’s link with your friends, and each of you open it on your own device.</p></div>`; return; }
  const r = route();
  app.innerHTML = r.view === "table" ? viewTable() : viewHome();
  if (fk){ const el = app.querySelector(`[data-focus="${fk}"]`); if (el){ el.focus({preventScroll:true}); try { el.setSelectionRange(el.value.length, el.value.length); } catch {} } }
}
function viewHome(){
  const inv = invites(), mine = myTables();
  return `${inv.length ? `<div class="invites" role="status">${inv.map(g => `<div class="invite">
      <span class="t"><b>${esc(nameOf(g, g.host))}</b> is hosting table <b>${esc(g.id)}</b>. ${seats(g).length} seated.</span>
      <button class="btn primary small" data-act="open" data-code="${esc(g.id)}">Join</button>
      <button class="x" data-act="dismiss" data-code="${esc(g.id)}" aria-label="Dismiss">✕</button></div>`).join("")}</div>` : ""}
  <div class="home">
    <section>
      <h1>Deal a hand of rummy with your friends.</h1>
      <p class="lead">Start a table and everyone on the same Wi-Fi gets a notice to join, or share the 5-letter code. Each player plays on their own phone. 13-card rummy with jokers, drops and pool scoring.</p>
      <div class="panel stack">
        <div><label class="f" for="nm">Your name</label><input id="nm" class="inp" data-bind="name" data-focus="nm" maxlength="20" placeholder="e.g. Asha" value="${esc(ui.name)}"></div>
        <button class="btn primary" data-act="create">Start a new table</button>
        <div class="row"><div style="flex:1"><label class="f" for="cd">Or join with a code</label><input id="cd" class="inp code-inp" data-bind="code" data-focus="cd" data-enter="join" maxlength="5" placeholder="ABCDE" value="${esc(ui.code)}" autocomplete="off"></div><button class="btn" data-act="join">Join</button></div>
        ${ui.err ? `<div class="err">${esc(ui.err)}</div>` : ""}
      </div>
      ${howTo()}
    </section>
    <section class="panel">
      <h2 style="font-size:21px">Your tables</h2>
      ${!S.listLoaded ? `<p class="muted">Loading…</p>` : mine.length ? `<div class="tlist">${mine.map(g => {
        const ps = seats(g);
        return `<button class="trow" data-act="open" data-code="${esc(g.id)}"><span class="c">${esc(g.id)}</span><span class="n">${ps.map(p => esc(p.name)).join(", ")}</span><span class="pill ${g.status === "lobby" ? "lobby" : "live"}">${g.status === "lobby" ? "Waiting" : "Deal " + (g.cur || 1)}</span></button>`;
      }).join("")}</div>` : `<p class="muted">You’re not at any table yet. When a friend hosts one, a notice with a Join button shows up at the top of this page.</p>`}
    </section>
  </div>`;
}
function howTo(){
  return `<details class="how"><summary>How to play</summary><ul>
    <li>Everyone gets 13 cards. One card is turned up as the wild joker: every card of that rank (★) plus the printed jokers (3 in every deck) can stand in for anything.</li>
    <li>On your turn, draw from the stock or take the top discard, then discard one card.</li>
    <li>Tap cards to select them, then Group them into sequences (same suit in order, like 5♥ 6♥ 7♥) or a motta (same rank, different suits, like 4♦ 4♣ 4♠). Only one motta is allowed in a hand. A Japan (same rank and same suit, like 7♥ 7♥ 7♥) counts as a pure sequence.</li>
    <li>To win, you need at least two sequences, one of them pure (no jokers), with every card in a meld. Select your last card and tap the big RUMMY button.</li>
    <li>Losers score only the cards that aren’t in a valid group (pure sequence, Japan, sequence or motta), up to 80. On a hidden joker table, anyone who hasn’t seen the joker scores 80. Drop before your first draw: 20, after drawing: 40. Reach the limit (101, 201, 240 or a custom number) and you’re out. Last player standing wins.</li>
    <li>Hidden joker tables: the wild joker stays face down until you have a pure sequence (or Japan) as its own group. If you’re dealt one, it’s grouped for you and you see the joker at once; otherwise it’s shown after your discard.</li>
  </ul></details>`;
}
function viewTable(){
  const g = S.game;
  if (!S.gameLoaded) return `<div class="loading">Finding the table…</div>`;
  if (!g) return `<div class="panel" style="max-width:520px;margin:30px auto"><h2>No table with code ${esc(S.gameCode)}</h2><p class="muted">Check the code with your friend, or <a href="#" style="color:inherit">go back</a> and start a new one.</p></div>`;
  document.getElementById("hdr").innerHTML = `<span class="pill" style="letter-spacing:.14em">${esc(g.id)}</span>`;
  const stale = S.stale ? `<div class="banner">Can’t reach the table right now. What you see may be out of date.</div>` : "";
  if (g.status === "lobby") return stale + viewLobby(g);
  return stale + viewPlay(g);
}
function viewLobby(g){
  const ps = seats(g), mine = ps.some(p => p.id === S.me), host = g.host === S.me || S.isOwner, st = settings(g);
  return `<div class="lobby panel">
    <p class="muted" style="margin:0">Share this code with your friends</p>
    <div class="bigcode">${esc(g.id)}</div>
    <p class="muted" style="margin:0 0 6px">They open this same page, type the code, and take a seat.</p>
    <div class="plist">${ps.map(p => `<div class="prow"><span class="nm">${esc(p.name)}${p.id === g.host ? ' <span class="pill">Host</span>' : ""}${p.id === S.me ? ' <span class="pill lobby">You</span>' : ""}</span>
      ${(host && p.id !== S.me) || (p.id === S.me && !host) ? `<button class="btn small" data-act="leave" data-pid="${p.id}">${p.id === S.me ? "Leave" : "Remove"}</button>` : ""}</div>`).join("")}</div>
    <p class="muted" style="font-size:13.5px">${ps.length} of 10 players. ${decksFor(ps.length) ? `Plays with ${decksFor(ps.length)} decks and ${decksFor(ps.length) * JOKERS_PER_DECK} printed jokers.` : "Need at least 2 players."}</p>
    ${mine ? "" : `<div class="row" style="margin:12px 0"><div style="flex:1"><label class="f" for="jn">Your name</label><input id="jn" class="inp" data-bind="joinName" data-focus="jn" data-enter="sit" maxlength="20" value="${esc(ui.joinName || ui.name)}"></div><button class="btn primary" data-act="sit">Take a seat</button></div>`}
    ${ui.err ? `<div class="err">${esc(ui.err)}</div>` : ""}
    <label class="f" style="margin-top:14px">Players are out at</label>
    <div class="chips">${MAX_PRESETS.map(v => `<button class="chip" data-act="max" data-v="${v}" aria-pressed="${st.maxScore === v}" ${host ? "" : "disabled"}>${v} points</button>`).join("")}
      ${MAX_PRESETS.includes(st.maxScore) ? "" : `<button class="chip" aria-pressed="true" disabled>${st.maxScore} points</button>`}
      ${host ? `<span class="cust"><input class="inp num" type="number" inputmode="numeric" min="${MAX_MIN}" max="${MAX_MAX}" aria-label="Custom points" placeholder="Custom" data-bind="customMax" data-focus="cm" data-enter="customMax" value="${esc(ui.customMax)}"><button class="btn small" data-act="customMax">Set</button></span>` : ""}</div>
    <label class="f" style="margin-top:14px">Wild joker</label>
    <div class="chips">${[["open","Open"],["hidden","Hidden"]].map(([v, t]) => `<button class="chip" data-act="joker" data-v="${v}" aria-pressed="${st.jokerMode === v}" ${host ? "" : "disabled"}>${t}</button>`).join("")}</div>
    <p class="muted" style="font-size:13px;margin:6px 0 0">${st.jokerMode === "hidden" ? "The wild joker is dealt face down. Each player sees it once they have a pure sequence (or Japan) grouped on its own: at the deal, or after their discard." : "The wild joker is shown face up to everyone from the start."}</p>
    <div style="display:flex;gap:8px;justify-content:space-between;margin-top:20px;flex-wrap:wrap">
      ${host ? `<button class="btn danger" data-act="del">Close table</button><button class="btn primary" data-act="start" ${ps.length >= 2 ? "" : "disabled"}>Deal the cards</button>` : `<span class="muted">Waiting for ${esc(nameOf(g, g.host))} to deal…</span>`}
    </div>
  </div>`;
}
function viewPlay(g){
  const d = curDeal(g), st = settings(g), {t} = totals(g), ps = seats(g);
  const host = g.host === S.me || S.isOwner;
  if (!d) return `<div class="loading">Dealing…</div>`;
  const inDeal = d.players.includes(S.me);
  const myGroups = inDeal ? (d.hands[S.me] || []) : null;
  const allMine = myGroups ? myGroups.flat() : [];
  ui.sel = ui.sel.filter(id => allMine.includes(id));
  const vw = viewWild(d);

  let html = `<div class="tbar"><h2>Deal ${d.n}</h2>
    <span class="muted" style="display:flex;align-items:center;gap:8px">Wild joker ${vw ? cardHTML(d.cut, null, {sm:true}) : `<span class="card sm back" role="img" aria-label="Hidden"></span> hidden`}</span>
    <div class="sp"><button class="btn small" data-act="scores">${ui.showScores ? "Hide scores" : "Scores"}</button>${isSeated(g) && g.status === "playing" ? `<button class="btn small danger" data-act="quit">Leave</button>` : ""}</div></div>`;

  html += `<div class="opps">${ps.map(p => {
    const pIn = d.players.includes(p.id), out = d.out[p.id], elim = t[p.id] >= st.maxScore && !pIn;
    const n = pIn && d.hands[p.id] ? d.hands[p.id].flat().length : 0;
    const turn = d.status === "live" && d.turn === p.id;
    const crown = d.hidden && d.seen && d.seen[p.id];
    return `<div class="opp ${turn ? "turn" : ""} ${out || elim || p.left ? "gone" : ""} ${p.id === S.me ? "me" : ""} ${crown ? "crowned" : ""}" ${crown ? `title="Has seen the wild joker"` : ""}>
      <div class="nm">${esc(p.name)}${crown ? `<span class="sr-only"> (has seen the wild joker)</span>` : ""}</div>
      <div class="meta num">${t[p.id]} pts${pIn && !out ? `, ${n} cards` : ""}</div>
      ${p.left ? `<div class="tag">Left the table</div>` : elim ? `<div class="tag">Out of the game</div>` : out === "drop" ? `<div class="tag">Dropped</div>` : out === "wrong" ? `<div class="tag">Wrong show</div>` : turn ? `<div class="tag" style="color:var(--brass)">Playing…</div>` : ""}
      ${host && p.id !== S.me && !p.left && g.status === "playing" ? `<button class="kick" data-act="quit" data-pid="${p.id}">Remove</button>` : ""}
    </div>`;
  }).join("")}</div>`;

  if (g.status === "over") html += champion(g, t);
  else if (d.status === "done") html += resultPanel(g, d);

  if (d.status === "live"){
    const top = d.discard[d.discard.length - 1];
    const canDraw = myTurn(d, "draw");
    const status = d.turn === S.me ? (d.phase === "draw" ? "Your turn: draw from the stock or take the discard." : "Your turn: select a card to discard, or call Rummy.") : `Waiting for ${esc(nameOf(g, d.turn))}…`;
    html += `<div class="center">
      <div class="pile ${canDraw ? "can" : ""}">${canDraw ? `<button class="card back" data-act="drawStock" aria-label="Draw from stock"></button>` : `<span class="card back"></span>`}<span class="num">Stock ${d.stock.length}</span></div>
      <div class="pile ${canDraw && top ? "can" : ""}">${top ? cardHTML(top, vw, canDraw ? {act:'data-act="drawDiscard"'} : {}) : `<span class="card" style="opacity:.2"></span>`}<span>Discard</span></div>
      <div class="pile wildc">${vw ? cardHTML(d.cut, null) : `<span class="card back" role="img" aria-label="Wild joker, hidden">?</span>`}<span class="wl">${vw ? `Wild joker: every ${d.wild} ★` : "Wild joker hidden. Group a pure sequence and discard to see it."}</span></div>
      <div class="status ${d.turn === S.me ? "mine" : ""}">${status}</div>
      <div class="last">${esc(d.last || "")}</div>
    </div>`;
  }

  if (myGroups && !d.out[S.me] && d.status === "live"){
    const ev = evalHand(myGroups, vw);
    const fresh = d.fresh && d.fresh[S.me];
    html += `<div class="hand">${myGroups.map((gr, i) => {
      const k = ev.kinds[i];
      return `<div class="grp"><div class="cards">${gr.map(id => cardHTML(id, vw, {act:`data-act="sel" data-id="${id}"`, sel:ui.sel.includes(id), fresh:id === fresh})).join("")}</div>
        <div class="lab ${k}">${gr.length < 3 ? gr.length + (gr.length === 1 ? " card" : " cards") : KIND_LABEL[k]}${ui.sel.length && !ui.sel.every(id => gr.includes(id)) ? ` <button class="movehere" data-act="moveTo" data-i="${i}">Move here</button>` : ""}</div></div>`;
    }).join("")}</div>
    <div class="hand-pts">If someone calls Rummy now, you’d score <b class="num">${missedJoker(d, S.me) ? st.fullCount : handPoints(myGroups, vw, st.fullCount)}</b>.${missedJoker(d, S.me) ? " You haven’t seen the wild joker yet." : ev.pure ? "" : " You still need a pure sequence."}</div>`;
    bar.innerHTML = actionBar(g, d, host);
  } else if (d.status === "live"){
    html += `<p class="muted" style="text-align:center">${inDeal ? "You’re sitting out the rest of this deal." : spectating(g, d) ? "You’re out of the game. You can watch everyone’s cards." : "You’re watching this deal."}</p>`;
    if (spectating(g, d)) html += spectateHands(g, d);
    if (host && d.turn !== S.me && Date.now() - (d.turnAt || 0) > 90000) bar.innerHTML = hostBar(g, d);
  }
  if (ui.showScores || g.status === "over") html += scoreTable(g);
  return html;
}
function spectateHands(g, d){
  return `<section class="spec"><h3>Players’ cards</h3>${d.players.filter(p => !d.out[p]).map(p => {
    const groups = d.hands[p] || [], ev = evalHand(groups, d.wild);
    return `<div class="rrow"><span class="who">${esc(nameOf(g, p))}${d.turn === p ? ` <span class="pill lobby">Playing</span>` : ""}</span>
      <div class="rgroups">${groups.map((gr, i) => `<div class="g ${isMeld(ev.kinds[i]) || gr.length < 3 ? "" : "bad"}">${gr.map(id => cardHTML(id, d.wild, {sm:true})).join("")}</div>`).join("")}</div></div>`;
  }).join("")}</section>`;
}
function actionBar(g, d, host){
  const mine = d.turn === S.me, ph = d.phase, n = ui.sel.length;
  const hint = mine && ph === "discard" ? (n === 1 ? "Discard it, or tap RUMMY to finish with this card." : "Select one card to discard.") : n ? `${n} selected. Group them, or tap Move here on a group.` : "Tap cards to select them.";
  return `<div class="actions"><div class="in">
    <button class="btn" data-act="group" ${n ? "" : "disabled"}>Group</button>
    <button class="btn" data-act="sort">Sort</button>
    ${mine && ph === "discard" ? `<button class="btn primary" data-act="discard" ${n === 1 ? "" : "disabled"}>Discard</button>` : ""}
    ${mine ? `<button class="btn danger" data-act="drop">Drop</button>` : ""}
    ${!mine && host && Date.now() - (d.turnAt || 0) > 90000 ? `<button class="btn small" data-act="drop" data-pid="${d.turn}" title="Use if this player has left">Drop ${esc(nameOf(g, d.turn))}</button>` : ""}
    <div class="hint">${hint}</div>
  </div></div>${mine && ph === "discard" ? `<button class="rummy" data-act="declare" ${n === 1 ? "" : "disabled"} title="Select your last card, then tap to show">RUMMY</button>` : ""}`;
}
function hostBar(g, d){
  return `<div class="actions"><div class="in"><span class="muted" style="font-size:13px">Is ${esc(nameOf(g, d.turn))} away?</span><button class="btn small" data-act="drop" data-pid="${d.turn}">Drop them for this deal</button></div></div>`;
}
function resultPanel(g, d){
  const r = d.result, w = r.winner;
  const head = r.how === "declare" ? `${esc(nameOf(g, w))} called Rummy and wins deal ${d.n}` : `${esc(nameOf(g, w))} wins deal ${d.n}`;
  const rows = d.players.map(p => {
    const why = p === w ? (r.how === "declare" ? "Valid show" : "Last player in") : d.out[p] === "drop" ? (d.drawn && d.drawn[p] ? "Middle drop" : "First drop") : d.out[p] === "wrong" ? "Wrong show" : d.out[p] === "left" ? "Left the table" : missedJoker(d, p) ? "Joker not seen" : "Unmelded cards";
    const groups = d.hands[p] || [], ev = evalHand(groups, d.wild);
    return `<div class="rrow"><span class="who">${esc(nameOf(g, p))}</span><span class="p num ${r.scores[p] === 0 ? "zero" : ""}">${r.scores[p]}</span><span class="why">${why}</span>
      ${d.out[p] === "drop" || d.out[p] === "left" || (p === w && r.how === "last") ? "" : `<div class="rgroups">${groups.map((gr, i) => `<div class="g ${isMeld(ev.kinds[i]) ? "" : "bad"}">${gr.map(id => cardHTML(id, d.wild, {sm:true})).join("")}</div>`).join("")}</div>`}</div>`;
  }).join("");
  return `<div class="result"><h2>${head}</h2><p class="muted" style="margin:0 0 8px">Wild joker was ${label(d.cut).replace("a joker","the printed joker")}. Red groups weren’t valid melds.</p>${rows}
    <div style="display:flex;justify-content:flex-end;margin-top:12px"><button class="btn primary" data-act="nextDeal">Deal next hand</button></div></div>`;
}
function champion(g, t){
  const c = g.champion; const nxt = g.next;
  return `<div class="result champ"><div class="crown" aria-hidden="true">♛</div><h2>${esc(nameOf(g, c))} wins the game</h2>
    <p class="muted">Final score ${t[c]}. Everyone else reached ${settings(g).maxScore}.</p>
    <div style="display:flex;gap:8px;justify-content:center;margin-top:14px">${nxt ? `<button class="btn primary" data-act="open" data-code="${esc(nxt)}">Join the rematch</button>` : `<button class="btn primary" data-act="again">Rematch with same players</button>`}<a class="btn" href="#" style="text-decoration:none">Home</a></div></div>`;
}
function scoreTable(g){
  const ps = seats(g), {t, list} = totals(g), max = settings(g).maxScore;
  const alive = ps.filter(p => !p.left && t[p.id] < max), low = alive.length ? Math.min(...alive.map(p => t[p.id])) : null;
  return `<section id="scores" style="margin-top:18px"><h2 style="font-size:21px">Scoreboard <span class="muted" style="font-family:Manrope,sans-serif;font-size:14px">out at ${max}</span></h2>
    <div class="sbw"><table class="sb"><thead><tr><th>Deal</th>${ps.map(p => `<th>${esc(p.name)}${p.left ? ` <span class="muted">(left)</span>` : ""}</th>`).join("")}</tr></thead>
    <tbody>${list.length ? list.map(d => `<tr><td>Deal ${d.n}</td>${ps.map(p => { const v = d.result.scores[p.id]; return `<td class="num ${v === 0 ? "zero" : ""}">${v == null ? "–" : v}</td>`; }).join("")}</tr>`).join("") : `<tr><td colspan="${ps.length + 1}" class="muted" style="text-align:left">No deals finished yet.</td></tr>`}</tbody>
    <tfoot><tr><td>Total</td>${ps.map(p => `<td class="num ${t[p.id] >= max ? "out" : t[p.id] === low && list.length ? "low" : ""}">${t[p.id]}${t[p.id] >= max ? " ✕" : ""}</td>`).join("")}</tr></tfoot></table></div></section>`;
}

/* ================= Events ================= */
function toast(msg, bad){ const el = document.createElement("div"); el.className = "toast" + (bad ? " bad" : ""); el.textContent = msg; el.setAttribute("role","status"); document.body.appendChild(el); setTimeout(() => el.remove(), 3000); }
function confirmBox(title, text, yes){
  const dlg = document.getElementById("dlg");
  document.getElementById("dlg-t").textContent = title; document.getElementById("dlg-p").textContent = text; document.getElementById("dlg-yes").textContent = yes;
  return new Promise(res => { const done = v => { dlg.close(); res(v); };
    document.getElementById("dlg-yes").onclick = () => done(true); document.getElementById("dlg-no").onclick = () => done(false); dlg.oncancel = () => res(false); dlg.showModal(); });
}
document.addEventListener("click", e => {
  const b = e.target.closest("[data-act]"); if (!b || b.disabled) return;
  const fn = A[b.dataset.act]; if (!fn) return;
  if (b.tagName === "A") e.preventDefault();
  fn(b.dataset);
});
app.addEventListener("input", e => {
  const t = e.target; if (!t.dataset.bind) return;
  let v = t.value; if (t.dataset.bind === "code"){ v = v.toUpperCase().replace(/[^A-Z0-9]/g, ""); if (t.value !== v) t.value = v; }
  ui[t.dataset.bind] = v;
});
app.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.dataset.enter){ e.preventDefault(); A[e.target.dataset.enter](); } });

render(); boot();
setInterval(() => { const d = S.game && curDeal(S.game); if (d && d.status === "live" && Date.now() - (d.turnAt || 0) > 90000 && !document.querySelector("dialog[open]")) render(); }, 15000);
</script>
</body>
</html>
"""


if __name__ == "__main__":
    load()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print("Rummy with Friends is running.")
    print(f"  On this computer:      http://localhost:{PORT}")
    print(f"  On phones (same Wi-Fi): http://{lan_ip()}:{PORT}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
