# Rummy with Friends

Play 13-card rummy with 2–10 friends, each on their own phone, with a live scoreboard.

## What you need
- Python 3.8 or newer (https://www.python.org/downloads/). Nothing else to install.
- One computer to run the game, and everyone on the same Wi-Fi.

## Start the game
- **Windows:** double-click `start-windows.bat`
- **Mac / Linux:** run `./start-mac-linux.sh` in a terminal (or `python3 rummy.py`)

It prints two addresses:

    On this computer:       http://localhost:8000
    On phones (same Wi-Fi): http://192.168.x.x:8000

Everyone opens the phone address in their browser.

## Play
1. Enter your name and tap **Start a new table**. You get a 5-letter code.
2. Friends enter the code and tap **Take a seat**.
3. The host picks the points limit (101, 201, 240 or a custom number), chooses an Open or Hidden wild joker (hidden: you see it once a pure sequence or Japan is grouped on its own), and taps **Deal the cards**.
4. On your turn: draw from the stock or discard pile, then discard one card.
5. Tap cards to select them, then **Group** them into sequences or a motta (same number, different suits, like 4♦ 4♣ 4♠).
6. With two sequences (one pure) and every card melded, select your last card and tap the big **RUMMY** button.
7. Need to go? Tap **Leave**. You get the drop penalty for the current deal (20 or 40) and sit out the rest of the game. The host can **Remove** a player the same way.
8. Out on points? You can keep watching: you see the wild joker and every player's cards. If you drop, you see the wild joker for the rest of that deal.

Scoring: only cards not in a valid group count, so a motta or sequence scores 0 (max 80), first drop (before your first draw) 20, middle drop 40, wrong show 80. On a hidden joker table, a player who never saw the joker scores 80.
A Japan (same number and same suit, like 7♥ 7♥ 7♥) counts as a pure sequence; same number with different suits is a motta, and only one motta is allowed in a hand.
Reach the limit and you're out. The last player left wins.
Decks are chosen automatically: 3 decks for 2–6 players, 5 decks for 7–10. Each deck has 3 printed jokers.

## Good to know
- Keep the computer and terminal running while you play.
- Games are saved in `rummy_data.json` next to `rummy.py`; tables older than 7 days are removed.
- Port busy? Run `python rummy.py 8080`.
- Phones can't connect? Allow Python through your firewall (on Windows choose "Private networks").

## Files
- `rummy.py` – the whole app (server + game page). This is all you need.
- `start-windows.bat`, `start-mac-linux.sh` – one-click starters.
- `extras/` – the versions built for claude.ai (they only sync players when opened from their claude.ai links):
  - `rummy-game-claude.html` – the same game
  - `rummy-scoreboard-claude.html` – scoreboard-only app for games played with real cards
