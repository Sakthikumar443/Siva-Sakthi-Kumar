@echo off
cd /d "%~dp0"
where python >nul 2>nul && (python rummy.py) || (py rummy.py)
pause
